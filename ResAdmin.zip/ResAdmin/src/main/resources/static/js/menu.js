window.onload = function(){
    const btn = document.getElementById('menuBtn');
    btn.addEventListener('click',sendit);
}

function sendit(){

    const mName = document.getElementById("mName");
    const mPrice = document.getElementById("mPrice");
    const mContent = document.getElementById("mContent");

    if (mName.value == "") {
        alert('메뉴 이름 입력하세요');
        mName.focus()
        return false;
    }

    if (mPrice.value == "") {
        alert('가격 입력하세요');
        mPrice.focus()
        return false;
    }

    fetch('http://localhost:8888/api/menu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            "transaction_time":`${new Date()}`,
            "resultCode":"ok",
            "description":"정상",
            "data":{
                "mName":`${mName.value}`,
                "mContent":`${mContent.value}`,
                "mPrice":`${mPrice.value}`
            }
        }),
    })
        .then((res) => {
            alert('등록성공')
            location.href='/menuLookUp';
            return;
        })
        .then((data) => {
            console.log(data);
            return;
        })
        .catch((err) => {
            alert('에러!');
            location.reload();
            return;
        });

    // fetch
    return true;
}
package com.catchmind.resadmin.model.network.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MenuApiResponse {
    private Long mIdx;
    private String mName;
    private String mContent;
    private String mPrice;
    private LocalDateTime regDate;
    private Long mIdx2;

}